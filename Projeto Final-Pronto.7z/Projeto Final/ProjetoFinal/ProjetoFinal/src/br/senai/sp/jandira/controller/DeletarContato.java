package br.senai.sp.jandira.controller;

public class DeletarContato {
}
